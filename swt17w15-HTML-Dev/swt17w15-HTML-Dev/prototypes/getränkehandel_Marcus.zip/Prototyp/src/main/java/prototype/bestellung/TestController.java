package prototype.bestellung;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TestController {
	private Bestellungsmanagement bm;
	
	public TestController(Bestellungsmanagement bm){
		this.bm = bm;
	}
	
	@GetMapping("/orders")
	String orders(@RequestParam Optional<String> name, Model model){
		return "bestellungen";
	}
	
	@ModelAttribute("bestellungen")
	List<Bestellung> initializeBestellungen() {
		return this.bm.getOffeneBestellungen();
	}

}
