package Getraenkehandel.controller;

import org.salespointframework.core.DataInitializer;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.Arrays;

/**
 * Created by Leon Röscher on 14.11.2017.
 */
@Component
public class SetupInitializer implements DataInitializer {

    private final UserAccountManager userAccountManager;


    /**
     * @param userAccountManager

     */
    SetupInitializer(UserAccountManager userAccountManager) {


        Assert.notNull(userAccountManager, "UserAccountManager must not be null!");

        this.userAccountManager = userAccountManager;

    }

    /*
     * (non-Javadoc)
     * @see org.salespointframework.core.DataInitializer#initialize()
     */
    @Override
    public void initialize() {

        // (｡◕‿◕｡)
        // UserAccounts bestehen aus einem Identifier und eine Password, diese werden auch für ein Login gebraucht
        // Zusätzlich kann ein UserAccount noch Rollen bekommen, diese können in den Controllern und im View dazu genutzt
        // werden
        // um bestimmte Bereiche nicht zugänglich zu machen, das "ROLE_"-Prefix ist eine Konvention welche für Spring
        // Security nötig ist.

        // Skip creation if database was already populated
        if (userAccountManager.findByUsername("boss").isPresent()) {
            return;
        }

        UserAccount bossAccount = userAccountManager.create("boss", "123", Role.of("ROLE_BOSS"));
        userAccountManager.save(bossAccount);

        Role customerRole = Role.of("ROLE_CUSTOMER");

        UserAccount ua1 = userAccountManager.create("hans", "123", customerRole);
        UserAccount ua2 = userAccountManager.create("dextermorgan", "123", customerRole);
        UserAccount ua3 = userAccountManager.create("earlhickey", "123", customerRole);
        UserAccount ua4 = userAccountManager.create("mclovinfogell", "123", customerRole);
    }
}
