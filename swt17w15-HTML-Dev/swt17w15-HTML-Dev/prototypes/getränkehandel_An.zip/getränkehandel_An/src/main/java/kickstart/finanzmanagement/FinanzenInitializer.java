package kickstart.finanzmanagement;

import org.javamoney.moneta.Money;
import org.salespointframework.core.DataInitializer;
import org.salespointframework.order.ChargeLine;
import org.salespointframework.order.Order;
import org.salespointframework.order.OrderManager;
import org.salespointframework.order.OrderStatus;
import org.salespointframework.payment.Cash;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.stereotype.Component;

import javax.money.MonetaryAmount;

import static org.salespointframework.core.Currencies.EURO;

/**
 * Created by An on 13.11.2017.
 */
@Component
@org.springframework.core.annotation.Order(20)
public class FinanzenInitializer implements DataInitializer {

    private final OrderManager<Order> orderManager;
    private final UserAccountManager userAccountManager;

    FinanzenInitializer(OrderManager<Order> orderManager,UserAccountManager userAccountManager) {
        this. orderManager = orderManager;
        this.userAccountManager = userAccountManager;
    }


    @Override
    public void initialize() {

        Role customerRole = Role.of("ROLE_CUSTOMER");

        UserAccount ua1 = userAccountManager.create("hans", "123", customerRole);
        UserAccount ua2 = userAccountManager.create("dextermorgan", "123", customerRole);
        UserAccount ua3 = userAccountManager.create("earlhickey", "123", customerRole);
        UserAccount ua4 = userAccountManager.create("mclovinfogell", "123", customerRole);

        Order order1 = new Order(ua1,Cash.CASH);
        Order order2 = new Order(ua2,Cash.CASH);
        Order order3 = new Order(ua3,Cash.CASH);
        Order order4 = new Order(ua4,Cash.CASH);

        order1.add(new ChargeLine(Money.of(11000,EURO),"bla"));
        order2.add(new ChargeLine(Money.of(2000,EURO),"bla"));
        order3.add(new ChargeLine(Money.of(3000,EURO),"bla"));
        order4.add(new ChargeLine(Money.of(4000,EURO),"bla"));

        System.out.println(order1.getTotalPrice());


        orderManager.save(order1);
        orderManager.save(order2);
        orderManager.save(order3);
        orderManager.save(order4);

        orderManager.payOrder(order1);
        orderManager.payOrder(order2);
        orderManager.payOrder(order3);
        orderManager.payOrder(order4);

        System.out.println(order1.getOrderStatus());

        System.out.println(orderManager.findBy(OrderStatus.COMPLETED));

    }
}
