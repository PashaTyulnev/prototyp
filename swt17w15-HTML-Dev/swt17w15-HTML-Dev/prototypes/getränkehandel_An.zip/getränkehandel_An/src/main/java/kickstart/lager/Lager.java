package kickstart.lager;

import org.salespointframework.catalog.Catalog;
import org.salespointframework.catalog.Product;
import org.salespointframework.quantity.Quantity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by An on 15.11.2017.
 */
@Service
@Transactional
public class Lager {

    private final Catalog katalog;
    private final Map<Object,Quantity> map;

    Lager(Catalog katalog){
        this.map = new TreeMap<>();
        this.katalog = katalog;
    }

    public Map katalogmitanzahl(){
        for (Object p : katalog.findAll()) {
            map.put(p, Quantity.of(10));
        }
        return this.map;
    }
}
