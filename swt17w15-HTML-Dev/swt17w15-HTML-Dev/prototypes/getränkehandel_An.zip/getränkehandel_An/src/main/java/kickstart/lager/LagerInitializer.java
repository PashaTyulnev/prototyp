package kickstart.lager;

import org.javamoney.moneta.Money;
import org.salespointframework.catalog.Catalog;
import org.salespointframework.catalog.Product;
import org.salespointframework.core.DataInitializer;
import org.salespointframework.quantity.Quantity;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.TreeMap;

import static org.salespointframework.core.Currencies.EURO;

/**
 * Created by An on 15.11.2017.
 */
@Component
@Order(20)
public class LagerInitializer implements DataInitializer {

    private final Catalog<Product> katalog;

    LagerInitializer(Catalog katalog) {
        this.katalog = katalog;
    }


    @Override
    public void initialize() {

        katalog.save(new Product("Bier", Money.of(100, EURO)));
        katalog.save(new Product("Saft", Money.of(120, EURO)));
        katalog.save(new Product("Wein", Money.of(300, EURO)));
        katalog.save(new Product("Wasser", Money.of(200, EURO)));
        katalog.save(new Product("Cola", Money.of(150, EURO)));

    }

}
