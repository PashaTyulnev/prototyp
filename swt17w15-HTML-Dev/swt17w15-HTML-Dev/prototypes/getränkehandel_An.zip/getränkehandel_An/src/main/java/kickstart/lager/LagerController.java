package kickstart.lager;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Created by An on 15.11.2017.
 */
@Controller
public class LagerController {

    private final Lager lager;

    LagerController(Lager lager){
        this.lager = lager;
    }

    @GetMapping("/lager")
    String lager(Model model) {
        model.addAttribute("artikel" , lager.katalogmitanzahl());
        return "lager";
    }
}
